package com.example.lab1oop;


import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.Date;


public class TimeWorker extends HttpServlet {// 2 завдання
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        Date date = new Date();//створюємо об'єект дати
        req.setAttribute("date", date.toString());// встановлюємо атрибут для /time та передаємо значення
        req.getRequestDispatcher("time.jsp").forward(req, resp);
    }
}
