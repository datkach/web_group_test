package com.example.lab1oop;

import java.io.*;
import javax.servlet.http.*;
public class HelloServlet extends HttpServlet {//3 завдання
    public void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException {
        response.setContentType("text/html");
        // HelloWorld
        PrintWriter out = response.getWriter();
        out.println("<html><body>");
        out.println("<h1>HelloWorld</h1>");
        out.println("</body></html>");
    }
}