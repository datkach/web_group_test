package com.example.lab1oop;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

public class NameServlet extends HttpServlet {//4 завдання
    public void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException {
        response.setContentType("text/html");
        // ФИО, №курса и №группы, тема курсовой
        PrintWriter out = response.getWriter();
        out.println("<html><body>");
        out.println("<h1>Cheban Katerina 2 course AD-211 course Topic : \"medical centre\"</h1>");
        out.println("</body></html>");
    }
}
